import { Component } from '@angular/core';

@Component({
  selector: 'evt-sources-panel',
  templateUrl: './sources-panel.component.html',
  styleUrls: ['./sources-panel.component.scss'],
})
export class SourcesPanelComponent {
}
