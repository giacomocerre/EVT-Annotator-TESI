import { Component } from '@angular/core';

@Component({
  selector: 'evt-evt-info',
  templateUrl: './evt-info.component.html',
  styleUrls: ['./evt-info.component.scss'],
})
export class EvtInfoComponent {
}
